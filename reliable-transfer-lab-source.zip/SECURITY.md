# Security policy

Do not include secrets, private data or untrusted model files in issues or pull requests. Report vulnerabilities privately to the repository owner. This project is an educational portfolio implementation and is not a security-reviewed production service. Network and model interfaces have the limitations described in README and architecture documentation.
