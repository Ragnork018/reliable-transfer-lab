# Contributing

1. Create a focused branch and explain the problem being solved.
2. Add or update tests for behaviour changes.
3. Run the commands in README before opening a pull request.
4. Include reproducibility notes for model, data or network experiments.
5. Never commit API keys, private datasets, trained model artifacts or personal information.
