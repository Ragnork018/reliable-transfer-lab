# Changelog

## 1.0.0 — initial independent rebuild

- Added core application, architecture notes, tests and CI workflow.
- Initial release is a baseline implementation; see README for features that require user data, API credentials or a trained recognition model.
